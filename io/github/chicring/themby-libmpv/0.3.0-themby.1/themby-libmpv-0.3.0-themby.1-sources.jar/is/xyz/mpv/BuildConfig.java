/**
 * Automatically generated file. DO NOT MODIFY
 */
package is.xyz.mpv;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "is.xyz.mpv";
  public static final String BUILD_TYPE = "release";
}
